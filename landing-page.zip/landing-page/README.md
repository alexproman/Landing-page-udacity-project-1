# Landing page project

## Discription

It start with static version of landing page project by 'Udacity' , I make some adjustment to make it responsive page
 and built the Navigathion bar dynamicly by Javascript lanuage.

## The languages used

1- HTML       : the standard markup language for Web pages.
2- Css        : the language we use to style an HTML document.
3- Javascript : the programming language of the Web.

## What was implemented in this project

### HTML file

      1- linking javascript file witth HTML file.
      2- build multi-section landing page.
      3- add a button when click on it the page back to the top. 

### Css file

      1- add style to the navigation bar to make it responseve whith small screens.
      2- add style of the button who back the bage to the top.
      3- modify style of the active section on view port.

### Javascript file

      1- Building a dynamic navigation menu based on the sections of the page using JavaScript with unorderd list.
      2- when click on list Item in the navegation menu it will scroll the page smoothly to the linked section.
      3- Give Special style(highlight) to the section on view port and the list Item linked with when clicking the link or scrolling the bag.
      4- creting Button with scroll event and click event back to the top of the bage smoothly.

## APIS & methods used

    * document.querySelectorAll();   * document.getElementById();  * document.createElement();   * DocumentFragment();
    * preventDefault();              * addEventListener();         * scrollIntoView();           * getBoundingClientRect();
    * classList.add() , .remove()  , .contains()

## Sources

    - Document fragment();
        <https://developer.mozilla.org/en-US/docs/Web/API/DocumentFragment/DocumentFragment>

    - preventDefault();
        <https://developer.mozilla.org/en-US/docs/Web/API/Event/preventDefault>
    - addEventListener();
        <https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener>
    - getBoundingClientRect();
        <https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect>
    - claalist
        <https://developer.mozilla.org/en-US/docs/Web/API/Element/classList>

## Author

        Mohamed Abdel-Hamid Mohamed
